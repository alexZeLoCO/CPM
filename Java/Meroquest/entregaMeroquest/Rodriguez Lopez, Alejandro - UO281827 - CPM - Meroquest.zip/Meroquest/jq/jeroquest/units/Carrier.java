package jeroquest.units;

public interface Carrier {

    boolean isInfected();

    void setInfected(boolean infection);

}
