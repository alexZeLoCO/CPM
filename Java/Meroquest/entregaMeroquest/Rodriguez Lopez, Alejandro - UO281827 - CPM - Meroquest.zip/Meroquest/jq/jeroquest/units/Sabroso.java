package jeroquest.units;

public interface Sabroso {
    int sangrado();
}
