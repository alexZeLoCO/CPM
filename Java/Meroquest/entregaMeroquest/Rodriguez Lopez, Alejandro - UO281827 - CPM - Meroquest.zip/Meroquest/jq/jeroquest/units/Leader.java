package jeroquest.units;

public interface Leader {

    boolean isLeader();

    void setLeader(boolean leader);

}
