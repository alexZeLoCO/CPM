package jeroquest.units;

public interface Suspect {


    boolean isViolent();

    void setViolent(boolean violent);

}
