package jeroquest.units;

public interface Guard {

    void guard();
}
