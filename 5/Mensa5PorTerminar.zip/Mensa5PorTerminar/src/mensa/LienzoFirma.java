/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensa;

import java.awt.Color;
import java.awt.Graphics;
import java.util.LinkedList;
import java.awt.Point;
import java.util.Iterator;

/**
 *
 * @author quevedo
 */
public class LienzoFirma extends javax.swing.JPanel{
    LienzoFirma(){
        super();
        puntos=new LinkedList<>();
    }
    
    @Override
    public void paint(Graphics g){
        super.paint(g);

        Iterator<Point> i=puntos.iterator();
        while(i.hasNext()){
            Point p=i.next();
            // Pintar el punto p con el color y radio indicados
        }
            
    }
    
    public void insertaPunto(Point p){
           puntos.add(p);
    }
    
    public void borra(){
        puntos.clear();
    }
    
    private LinkedList<Point> puntos; // Puntos que forman el trazo
}
